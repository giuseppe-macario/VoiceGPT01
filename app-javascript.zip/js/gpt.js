export async function getGPTResponse(apiKey, input) {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "L'argomento è informatica, quindi se trovi sigle o frasi incomplete, interpretale sempre in un contesto informatico. Ti viene proposto, senza punto interrogativo, il testo di una domanda seguito facoltativamente da non più di quattro risposte alternative, scritte su righe distinte e quindi separate da un newline. Devi scegliere una sola risposta corretta, specificando subito se è la prima, seconda, terza o quarta; se nessuna alternativa fosse corretta, scegli quella meno inesatta rispetto alle altre, specificando subito se hai scelto la prima, seconda, terza o quarta. Se non fosse proposta nessuna alternativa, fornisci una risposta lunga non più di tre frasi. Se è richiesto un risultato numerico, fornisci solo il risultato senza elencare i calcoli. Se la domanda contiene solo un sostantivo o una breve frase, spiegane da un punto di vista tecnico il suo significato e/o il suo scopo e/o il suo utilizzo, in non più di tre frasi. Infine tieni presente che, per difficoltà di digitazione, potrebbero esserci errori come apostrofi mancanti, accenti mancanti (per esempio 'e' anziché 'è'), trattini mancanti, virgole e punti mancanti, caratteri digitati errati o mancanti (per esempio 'imput' anziché 'input', 'sceda' anziché 'scheda') ecc."
        },
        { role: "user", content: input }
      ]
    })
  });

  if (!response.ok) {
    throw new Error(`Errore API: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data?.choices?.[0]?.message?.content ?? "Errore nella risposta.";
}
