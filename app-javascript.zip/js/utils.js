export async function loadApiKey() {
  const response = await fetch("config.json");
  if (!response.ok) {
    throw new Error("Errore nel caricamento di config.json");
  }
  
  const config = await response.json();
  if (!config.api_key) {
    throw new Error("La chiave api_key non è presente in config.json");
  }

  return config.api_key;
}

export async function testConnection(apiKey) {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: "gpt-4o",
      messages: [{ role: "user", content: "ping" }]
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`API error (${response.status}): ${errText}`);
  }

  return true;
}
