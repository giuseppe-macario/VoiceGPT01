export function speak(text, rate = 1) {
  if (!('speechSynthesis' in window)) {
    throw new Error("Sintesi vocale non supportata.");
  }
  
  text = text.replace(/\n+/g, " , "); // Legge gli accapo come spazi
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = rate;
  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking() {  
  window.speechSynthesis.cancel();
}
