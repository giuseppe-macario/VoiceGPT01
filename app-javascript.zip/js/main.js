import { speak, stopSpeaking } from "./speech.js";
import { getGPTResponse } from "./gpt.js";
import { loadApiKey, testConnection } from "./utils.js";

document.addEventListener("DOMContentLoaded", async () => {
  const textarea = document.getElementById("question");
  const loading = document.getElementById("loading");
  const responseBox = document.getElementById("response");
  
  let apiKey = "";

  setTimeout(() => {
    textarea.focus();
  }, 100);

  try {
    apiKey = await loadApiKey();
    const ok = await testConnection(apiKey);
    responseBox.innerText = ok ? "Connessione riuscita" : "Errore di connessione a OpenAI";
  } catch (err) {
    responseBox.innerText = "Errore: " + err.message;
  }

  let backspacePressed = false;
  
  textarea.addEventListener("keydown", (e) => {
    if (e.key === "Backspace") {
      backspacePressed = true;
      stopSpeaking();
      speak("Indietro");
    }
    
    if (e.key === "Enter") {
      e.preventDefault();
    
      const lines = textarea.value.split("\n");
      const lastLine = lines[lines.length - 1];
      
      if (lastLine.trim() === "") {
        // L'ultima riga vuota, ottenuta col doppio Enter, invia la domanda
        handleSubmit();
      } else {
        const caretPos = textarea.selectionStart;
        const text = textarea.value;
        textarea.value = text.slice(0, caretPos) + "\n" + text.slice(caretPos);
        textarea.selectionStart = textarea.selectionEnd = caretPos + 1;
        
        stopSpeaking();
         
        // Leggi l'ultima parola prima di accapo
        const beforeCaret = text.slice(0, caretPos).trimEnd();
        const words = beforeCaret.split(/\s+/);
        const lastWord = words[words.length - 1] || "";
        
        if (lastWord) {
          speak(lastWord);
        }
        
        speak(" accapo");
      }
    }
  });
  
  textarea.addEventListener("input", () => {
    if (backspacePressed) {
      backspacePressed = false;
      return;
    }

    const text = textarea.value;
    const lastChar = text.slice(-1);

    stopSpeaking();

    if (lastChar === " ") {
      const words = text.trim().split(/\s+/);
      const lastWord = words[words.length - 1] || "";

      if (lastWord) {
        speak(lastWord);
      }
    } else {
      const charMap = { "y": "ipsilon", "Y": "ipsilon", ".": "punto" };
      const toSpeak = charMap[lastChar] || lastChar;
      speak(toSpeak);
    }
  });

  async function handleSubmit() {
    stopSpeaking();
    
    const input = textarea.value.trim();
    
    if (input === "") return;

    if (input === "reset") {
      textarea.value = "";
      responseBox.innerText = "";
      speak("Ripristino completato");
      return;
    }
    
    if (input === "ripeti") {
      speak(responseBox.innerText, 0.5);
      textarea.value = "";
      return;
    }
    
    loading.style.display = "block";
    speak(input);
    const waitUtterance = new SpeechSynthesisUtterance("Attendo");
    waitUtterance.onend = async () => {
      if (input === "test") {
        const ok = await testConnection(apiKey);
        const msg = ok ? "Connessione riuscita" : "Errore di connessione al server";
        responseBox.innerText = msg;
        speak(msg);
        textarea.value = "";
      }
      else { // il testo contiene una domanda per ChatGPT
        try {
          const output = await getGPTResponse(apiKey, input);
          responseBox.innerText = output;
          speak(output, 0.5);
        } catch (err) {
          responseBox.innerText = "Errore: " + err.message;
        }
      }
      
      loading.style.display = "none";
      textarea.value = "";
    };

    window.speechSynthesis.speak(waitUtterance);
  }
});